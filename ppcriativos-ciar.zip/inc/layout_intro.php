<div id="intro">
	
	<div class="grafismointro">
		<div class="posrel">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-01.png" data-mov="56 6 5">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-02.png" data-mov="58 6 6">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-03.png" data-mov="36 7 3">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-04.png" data-mov="44 3 3">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-05.png" data-mov="64 5 7">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-06.png" data-mov="60 3 3">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-07.png" data-mov="36 5 5">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-08.png" data-mov="34 8 8">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-09.png" data-mov="69 4 7">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-10.png" data-mov="59 2 8">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-11.png" data-mov="70 4 3">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-12.png" data-mov="53 7 4">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-13.png" data-mov="55 8 5">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-14.png" data-mov="38 6 2">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-15.png" data-mov="56 2 4">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-16.png" data-mov="57 3 7">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-17.png" data-mov="40 7 8">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-18.png" data-mov="43 7 3">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-19.png" data-mov="44 3 8">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-20.png" data-mov="60 4 8">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-21.png" data-mov="70 2 3">
			<img src="<?php bloginfo('template_url'); ?>/img/grafismos/grafismo-22.png" data-mov="70 4 5">
		</div>
	</div>
	<div id="logointro">
		<h3>Curso de Especialização</h3>
		<?php get_template_part('img/svg_marca'); ?>
	</div>
</div>