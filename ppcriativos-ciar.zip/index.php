<?php get_header(); ?>

<?php get_template_part('inc/layout_intro'); ?>
<?php get_template_part('inc/layout_noticias'); ?>
<?php get_template_part('inc/layout_sobre'); ?>
<?php get_template_part('inc/layout_equipe'); ?>
<?php get_template_part('inc/layout_modais'); ?>


<?php get_footer(); ?>